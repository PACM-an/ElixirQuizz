defmodule Credo.Service.SourceFileScopes do
  @moduledoc false

  use Credo.Service.ETSTableHelper
end
