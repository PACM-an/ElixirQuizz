[
  inputs: ["*.{ex,exs}", "{config,lib,test,script}/**/*.{ex,exs}"]
]
