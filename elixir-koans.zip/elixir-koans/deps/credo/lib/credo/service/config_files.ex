defmodule Credo.Service.ConfigFiles do
  @moduledoc false

  use Credo.Service.ETSTableHelper
end
